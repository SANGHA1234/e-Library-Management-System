﻿
    
    $(document).ready(function() {
        $('#dataTables-example').DataTable();
    } );
    