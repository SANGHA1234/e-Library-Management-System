-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2022 at 05:53 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `isbn` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `author_fname` varchar(100) DEFAULT NULL,
  `author_lname` varchar(100) DEFAULT NULL,
  `released_year` int(11) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `isbn`, `title`, `author_fname`, `author_lname`, `released_year`, `stock_quantity`) VALUES
(1, 256, '10% Happier', 'Dan', 'Harris', 2014, 29),
(2, 428, 'fake_book', 'Freida', 'Harris', 2001, 287),
(3, 367, 'Lincoln In The Bardo', 'George', 'Saunders', 2017, 50),
(4, 291, 'The Namesake', 'Jhumpa', 'Lahiri', 2003, 32),
(5, 304, 'Norse Mythology', 'Neil', 'Gaiman', 2016, 43),
(6, 465, 'American Gods', 'Neil', 'Gaiman', 2001, 12),
(7, 198, 'Interpreter of Maladies', 'Jhumpa', 'Lahiri', 1996, 97),
(8, 352, 'A Hologram for the King: A Novel', 'Dave', 'Eggers', 2012, 154),
(9, 504, 'The Circle', 'Dave', 'Eggers', 2013, 26),
(10, 634, 'The Amazing Adventures of Kavalier & Clay', 'Michael', 'Chabon', 2000, 68),
(11, 304, 'Just Kids', 'Patti', 'Smith', 2010, 55),
(12, 437, 'A Heartbreaking Work of Staggering Genius', 'Dave', 'Eggers', 2001, 104),
(13, 208, 'Coraline', 'Neil', 'Gaiman', 2003, 100),
(14, 176, 'What We Talk About When We Talk About Love: Stories', 'Raymond', 'Carver', 1981, 23),
(15, 526, 'Where I\'m Calling From: Selected Stories', 'Raymond', 'Carver', 1989, 12),
(16, 320, 'White Noise', 'Don', 'DeLillo', 1985, 49),
(17, 181, 'Cannery Row', 'John', 'Steinbeck', 1945, 95),
(18, 329, 'Oblivion: Stories', 'David', 'Foster Wallace', 2004, 172),
(19, 343, 'Consider the Lobster', 'David', 'Foster Wallace', 2005, 92);

-- --------------------------------------------------------

--
-- Table structure for table `borrowedbooks`
--

CREATE TABLE `borrowedbooks` (
  `book_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `member_name` varchar(100) DEFAULT NULL,
  `issued_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `librarians`
--

CREATE TABLE `librarians` (
  `id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarians`
--

INSERT INTO `librarians` (`id`, `name`, `userName`, `password`) VALUES
(1, 'Marie', 'Marie123', '123'),
(2, 'Raju', 'Raju123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(10) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(1, 'anil', 'kumar', 'ak@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `selectedbooks`
--

CREATE TABLE `selectedbooks` (
  `cnt` int(11) NOT NULL,
  `book_id` int(15) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `member_id` int(15) DEFAULT NULL,
  `member_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selectedbooks`
--

INSERT INTO `selectedbooks` (`cnt`, `book_id`, `title`, `member_id`, `member_name`) VALUES
(1, 1, '10% Happier', 1, 'anil, kumar'),
(2, 18, 'Oblivion: Stories', 1, 'anil, kumar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `librarians`
--
ALTER TABLE `librarians`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selectedbooks`
--
ALTER TABLE `selectedbooks`
  ADD PRIMARY KEY (`cnt`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `librarians`
--
ALTER TABLE `librarians`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `selectedbooks`
--
ALTER TABLE `selectedbooks`
  MODIFY `cnt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
